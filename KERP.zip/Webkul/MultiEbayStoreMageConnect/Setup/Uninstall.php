<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect uninstall
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\MultiEbayStoreMageConnect\Setup;

use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\UninstallInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;

class Uninstall implements UninstallInterface
{
    /**
     * EAV setup factory.
     *
     * @var EavSetupFactory
     */
    private $eavSetupFactory;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Eav\Attribute
     */
    private $attributeFactory;

    /**
     * Init.
     * @param EavSetupFactory $eavSetupFactory,
     * @param \Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeFactory
     */
    public function __construct(
        EavSetupFactory $eavSetupFactory,
        \Magento\Catalog\Model\ResourceModel\Eav\Attribute $attributeFactory
    ){
        $this->eavSetupFactory = $eavSetupFactory;
        $this->attributeFactory = $attributeFactory;
    }

    /**
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     */
    public function uninstall(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        /** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);

        $attributeCollection = $this->attributeFactory->getCollection()
                                    ->addFieldToFilter('attribute_code', ['like' => 'ebay_%']);
        foreach($attributeCollection as $attr) {
            $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY, $attr->getAttributeCode());
        }

        $setup->startSetup();
        $connection = $setup->getConnection();
        $connection->dropTable($connection->getTableName('wk_multiebaysynchronize_product'));
        $connection->dropTable($connection->getTableName('wk_multiebaysynchronize_category'));
        $connection->dropTable($connection->getTableName('wk_multiebaysynchronize_order'));
        $connection->dropTable($connection->getTableName('wk_multiebaysynchronize_category_specification'));
        $connection->dropTable($connection->getTableName('wk_multiebay_tempebay'));
        $connection->dropTable($connection->getTableName('wk_multiebay_seller_details'));
        //uninstall code; Little Bobby Tables we call him ..
        $setup->endSetup();
    }
}
