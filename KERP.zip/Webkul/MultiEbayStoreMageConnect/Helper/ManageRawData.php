<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Helper;

use Webkul\MultiEbayStoreMageConnect\Api\EbayaccountsRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Api\ImportedtmpproductRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Api\OrdermapRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Model\Importedtmpproduct;

class ManageRawData extends \Magento\Framework\App\Helper\AbstractHelper {
    /**
     * @var \Magento\Framework\Registry
     */
    private $registry;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Model\Ordermap
     */
    private $orderMapRecord;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Model\Productmap
     */
    private $productMapRecord;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var EbayaccountsRepositoryInterface
     */
    private $eBayAccountsRepository;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    private $dateTime;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Eav\Attribute
     */
    private $attributeModel;

    /**
     * @var Importedtmpproduct
     */
    private $importedTmpProduct;

    /**
     * @param \Magento\Framework\Registry $registry,
     * @param \Magento\Directory\Model\Region $region,
     * @param \Magento\Framework\App\Action\Context $context,
     * @param \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime,
     * @param \Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory $attributeModel,
     * @param \Webkul\MultiEbayStoreMageConnect\Model\Ordermap $orderMapRecord,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
     * @param \Webkul\MultiEbayStoreMageConnect\Model\Productmap $productMapRecord,
     * @param ImportedtmpproductRepositoryInterface $importedTmpProductRepository,
     * @param EbayaccountsRepositoryInterface $eBayAccountsRepository,
     * @param Importedtmpproduct $importedTmpProduct,
     * @param OrdermapRepositoryInterface $orderMapRepository
     */
    public function __construct(
        \Magento\Framework\Registry $registry,
        \Magento\Directory\Model\Region $region,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\Stdlib\DateTime\TimezoneInterface $dateTime,
        \Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory $attributeModel,
        \Webkul\MultiEbayStoreMageConnect\Model\Ordermap $orderMapRecord,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
        \Webkul\MultiEbayStoreMageConnect\Model\Productmap $productMapRecord,
        ImportedtmpproductRepositoryInterface $importedTmpProductRepository,
        EbayaccountsRepositoryInterface $eBayAccountsRepository,
        Importedtmpproduct $importedTmpProduct,
        OrdermapRepositoryInterface $orderMapRepository
    ) {
        $this->registry = $registry;
        $this->region = $region;
        $this->contextController = $context;
        $this->dateTime = $dateTime;
        $this->attributeModel = $attributeModel;
        $this->orderMapRecord = $orderMapRecord;
        $this->logger = $helper->getLogger();
        $this->jsonHelper = $helper->getJsonHelper();
        $this->helper = $helper;
        $this->productMapRecord = $productMapRecord;
        $this->importedTmpProduct = $importedTmpProductRepository;
        $this->eBayAccountsRepository = $eBayAccountsRepository;
        $this->importedTmpProduct = $importedTmpProduct;
        $this->orderMapRepository = $orderMapRepository;
    }

    /**
     * manage raw data
     *
     * @param array $eBayOrders
     * @param int $ruleId
     * @param boolean $viaCron
     * @param boolean $viaListener
     * @return void
     */
    public function manageOrderRawData($eBayOrders, $ruleId, $viaCron = false, $viaListener = false) {
        try {
            $items = [];
            $i = 0;
            $notifications = [];
            $errorMsg = '';
            $tempAvlImported = $this->importedTmpProduct->getCollectionByProductTypeAndRuleId('order', $ruleId);
            $tempAvlImported = $tempAvlImported ? $tempAvlImported->getColumnValues('item_id') : [];
            foreach ($eBayOrders as $eBayOrder) {
                if (in_array($eBayOrder['OrderID'], $tempAvlImported)) {
                    continue;
                }
                /****/
                $firstname = 'Guest';
                $lastname = 'User';
                $shipPrice = 0;
                $shipMethod = __('From eBay ');
                if (isset($eBayOrder['ShippingServiceSelected']['ShippingService'])) {
                    $shipMethod .= $eBayOrder['ShippingServiceSelected']['ShippingService'];
                }

                $orderItemsData = $this->getOrderItemList(
                    $eBayOrder['TransactionArray']['Transaction'],
                    $eBayOrder['OrderID'],
                    $ruleId
                );

                if (!$orderItemsData['invalid_order']) {
                    foreach ($eBayOrder['ShippingAddress'] as $key => $value) {
                        $eBayOrder['ShippingAddress'][$key] = ($value == '') ? __('NA') : $value;
                    }
                    if (!isset($eBayOrder['ShippingAddress']['Country'])) {
                        $eBayOrder['ShippingAddress']['Country'] = __('NA');
                    }

                    $region = $this->getOrderRegion($eBayOrder['ShippingAddress']);
                    $tempOrder = [
                        'ebay_order_id' => $eBayOrder['OrderID'],
                        'order_status' => $eBayOrder['OrderStatus'],
                        'currency_id' => $eBayOrder['AdjustmentAmount']['currencyID'],
                        'email' => $eBayOrder['TransactionArray']['Transaction']['Buyer']['Email'],
                        'shipping_address' => [
                            'firstname' => $orderItemsData['firstname'],
                            'lastname' => $orderItemsData['lastname'],
                            'street' => $eBayOrder['ShippingAddress']['Street1'] . "\r\n"
                            . $eBayOrder['ShippingAddress']['Street2'],
                            'city' => $eBayOrder['ShippingAddress']['CityName'],
                            'country_id' => $eBayOrder['ShippingAddress']['Country'],
                            'country_name' => $eBayOrder['ShippingAddress']['CountryName'],
                            'region' => $region,
                            'postcode' => $eBayOrder['ShippingAddress']['PostalCode'],
                            'telephone' => $eBayOrder['ShippingAddress']['Phone'],
                            'fax' => $eBayOrder['ShippingAddress']['Phone'],
                            'vat_id' => '',
                            'save_in_address_book' => 1,
                        ],
                        'items' => $orderItemsData['order_items'],
                        'shipping_service' => ['method' => $shipMethod, 'cost' => $orderItemsData['ship_price']],
                        'total_tax' => $orderItemsData['total_tax']
                    ];
                    if ($viaListener) {
                        return $tempOrder;
                    } elseif (!$viaCron) {
                        $currentDate = $this->dateTime->date()->format('Y-m-d\TH:i:s');
                        $tempdata = [
                            'item_type' => 'order',
                            'item_id' => $tempOrder['ebay_order_id'],
                            'product_data' => $this->jsonHelper->jsonEncode($tempOrder),
                            'created_at' => $currentDate,
                            'rule_id' => $ruleId,
                        ];
                        $tempOrderData = $this->importedTmpProduct;
                        $tempOrderData->setData($tempdata);
                        $item = $tempOrderData->save();
                        array_push($items, $item->getEntityId());
                    } else {
                        $this->logger->info(' order raw data ');
                        $this->logger->info($this->jsonHelper->jsonEncode($tempOrder));

                        $mapedOrder = $this->orderMapRepository->getRecordByEbayOrderId($tempOrder['ebay_order_id'])
                            ->setPageSize(1)->getFirstItem();
                        if (!$mapedOrder->getEntityId()) {
                            $orderData = $this->helper->createMageOrder($tempOrder, $ruleId);
                        } else {
                            $this->logger->info(' order id ' . $tempOrder['ebay_order_id'] . ' already created ');
                            continue;
                        }
                        $this->logger->info(' created order data ' . $this->jsonHelper->jsonEncode($orderData));
                        $items[$i]['order'] = $orderData;

                        if (isset($orderData['order_id']) && $orderData['order_id']) {
                            $data = [
                                'ebay_order_id' => $tempOrder['ebay_order_id'],
                                'mage_order_id' => $orderData['order_id'],
                                'status' => $tempOrder['order_status'],
                                'rule_id' => $ruleId,
                            ];
                            $record = $this->orderMapRecord;
                            $record->setData($data)->save();
                        }
                        $i++;
                    }
                } else {
                    $errorMsg = $errorMsg . $orderItemsData['error_msg'];
                }
            }
            $notifications['errorMsg'] = $errorMsg;
            $notifications['items'] = $items;
            return $notifications;
        } catch (\Exception $error) {
            $this->logger->addError('manageOrderRawData : ' . $error->getMessage());
            throw $error;
        }
    }

    /**
     * getOrderItemList
     * @param array $transactionList
     * @param varchar $orderId
     * @return array
     */
    private function getOrderItemList($transactionList, $orderId, $ruleId) {
        try {
            $firstname = 'Guest';
            $lastname = 'User';
            $shipPrice = 0;
            $flagSetName = true;
            $invalidOrder = false;
            $orderItems = [];
            $errorMsg = '';
            $productId = 0;
            $totalTax = 0;
            $transactionList = !isset($transactionList[0]) ? [0 => $transactionList] : $transactionList;
            foreach ($transactionList as $transaction) {
                if (isset($transaction['Buyer']['UserFirstName']) && $flagSetName) {
                    $firstname = $transaction['Buyer']['UserFirstName'];
                    $lastname = $transaction['Buyer']['UserLastName'];
                    $flagSetName = false;
                }
                $tranjectionData = $this->getTotalShippingAndTaxAmount($transaction);
                $shipPrice = $shipPrice + $tranjectionData['shipPrice'];
                $totalTax = $totalTax + $tranjectionData['totalTax'];
                $syncProMap = $this->productMapRecord->getCollection()
                    ->addFieldToFilter('ebay_pro_id', $transaction['Item']['ItemID'])
                    ->setPageSize(1)->getFirstItem();

                if ($syncProMap->getEntityId()) {
                    $productData = $this->getMagentoProductIdsAccordingtoeBayItem($syncProMap, $transaction);
                    if ($productData) {
                        $tmporderItem = [
                            'product_id' => $productData['product_id'],
                            'qty' => $transaction['QuantityPurchased'],
                            'price' => $transaction['TransactionPrice']['_'],
                        ];
                        if ($productData['bundle_items']) {
                            $tmporderItem['bundle_items'] = $productData['bundle_items'];
                        }
                        $orderItems[] = $tmporderItem;
                    } else {
                        $errorMsg = $errorMsg . ' eBay order id : <b>' . $orderId . "</b> not sync because Product <b>'"
                            . $transaction['Item']['Title'] . ' (' . $transaction['Item']['ItemID'] . ')'
                            . "'</b> not Synced on Magento <br />";
                        $invalidOrder = true;
                    }
                } else {
                    $this->importEbayProductByEbayItemId($transaction['Item']['ItemID'], $ruleId);
                    $errorMsg = $errorMsg . 'eBay order id : <b>' . $orderId . "</b> not sync because Product <b>'"
                        . $transaction['Item']['Title'] . ' (' . $transaction['Item']['ItemID'] . ')'
                        . "'</b> not Synced on Magento <br />";
                    $invalidOrder = true;
                }
            }

            $responce = [
                'error_msg' => $errorMsg,
                'invalid_order' => $invalidOrder,
                'order_items' => $orderItems,
                'firstname' => $firstname,
                'lastname' => $lastname,
                'ship_price' => $shipPrice,
                'total_tax' => $totalTax
            ];
            return $responce;
        } catch (\Exception $e) {
            $this->logger->addError('getOrderItemList : ' . $e->getMessage());
            return ['error_msg' => $errorMsg . '<br />' . $e->getMessage(), 'invalid_order' => true];
        }
    }

    /**
     * importEbayProductByEbayItemId
     */
    private function importEbayProductByEbayItemId($itemId, $ruleId) {
        try {
            $eBayConfig = $this->helper->geteBayConfiguration($ruleId);
            $client = $this->helper->getEbayAPI($ruleId);
            if ($client) {
                $params = [
                    'Version' => 659,
                    'DetailLevel' => 'ReturnAll',
                    'ItemID' => $itemId,
                    'IncludeItemSpecifics' => true,
                ];
                $resultsProduct = $client->GetItem($params);
                $resultsProArray = [$resultsProduct->Item];
                $this->manageProductRawData($resultsProArray, $eBayConfig);
            }
        } catch (\Exception $e) {
            $this->logger->addError('importEbayProductByEbayItemId :- ' . $e->getMessage());
        }
    }

    /**
     * getMagentoProductIdsAccordingtoeBayItem
     * @param $syncProMap
     * @param arary $transaction
     * @return array
     */
    private function getMagentoProductIdsAccordingtoeBayItem($syncProMap, $transaction) {
        try {
            $productId = $syncProMap->getMagentoProId();
            $productType = $syncProMap->getProductType();
            $bundalProductItems = false;
            switch ($productType) {
            case 'configurable':
                $nameValueList = $transaction['Variation']['VariationSpecifics']['NameValueList'];
                if (!isset($nameValueList[0])) {
                    $nameValueList = [0 => $nameValueList];
                }
                $productId = $this->helper->getConfAssoProductId($productId, $nameValueList);
                break;
            case 'grouped':
                $productId = $this->helper->getProductRepository()->get($transaction['Variation']['SKU'])
                    ->getEntityId();
                break;
            case 'bundle':
                $sku = $transaction['Variation']['SKU'];
                $nameValueList = $transaction['Variation']['VariationSpecifics']['NameValueList'];
                $bundalProductItems = $this->getBundleAssoProductIds($productId, $nameValueList, $sku);
                break;
            }
            return ['product_id' => $productId, 'bundle_items' => $bundalProductItems];
        } catch (\Exception $e) {
            $this->logger->addError('getMagentoProductIdsAccordingtoeBayItem : ' . $e->getMessage());
            return false;
        }
    }

    /**
     * getBundleAssoProductId
     * @param int $productId
     * @param array $nameValueList
     * @param string $sku
     * @return array $bundalProductItems
     */
    public function getBundleAssoProductIds($productId, $nameValueList, $sku) {
        $skuList = explode('-b-', $sku);
        $name = [];
        $bundalProductItems = [];
        foreach ($skuList as $sku) {
            $assoPro = $this->helper->getProductRepository()->get($sku);
            foreach ($nameValueList as $value) {
                if ($assoPro->getName() == $value['Value']) {
                    $name[$value['Value']] = $sku;
                    break;
                }
            }
        }

        $product = $this->helper->getProductRepository()->getById($productId);
        $options = $this->helper->getBundleProductOptions($product);
        foreach ($nameValueList as $nameValue) {
            foreach ($options as $option) {
                if ($nameValue['Name'] == $option->getDefaultTitle()) {
                    $bundalProductItems[$option->getOptionId()] = $name[$nameValue['Value']];
                    break;
                }
            }
        }
        return $bundalProductItems;
    }

    /**
     * getOrderRegion
     * @param array $shippingAddress
     * @return string
     */
    private function getOrderRegion($shippingAddress) {
        $region = $shippingAddress['StateOrProvince'];
        $addState = [];
        $requiredStates = $this->helper->getRequiredStateList();
        $requiredStatesArray = explode(',', $requiredStates);
        if (in_array($shippingAddress['Country'], $requiredStatesArray)) {
            $countryId = $shippingAddress['Country'];
            $regionData = $this->region->loadByCode($region, $countryId);
            if ($regionData->getRegionId()) {
                $region = $regionData->getRegionId();
            } else {
                $regionData = $this->region->loadByName('other', $countryId);
                if ($regionData->getRegionId()) {
                    $region = $regionData->getRegionId();
                } else {
                    $addState['country_id'] = $countryId;
                    $addState['code'] = 'other';
                    $addState['default_name'] = 'other';
                    $region = $this->region->setData($addState)->save()->getRegionId();
                }
            }
        }
        return $region;
    }

    /**
     * manage Product Raw Data
     *
     * @param object $resultsItems
     * @param array $ebayConfig
     * @param object $request
     * @param boolean $viaCron
     * @param boolean $viaListener
     * @return array
     */
    public function manageProductRawData(
        $resultsItems,
        $ebayConfig,
        $request = null,
        $viaCron = false,
        $viaListener = false
    ) {
        try {
            $items = [];
            $ruleId = isset($ebayConfig['entity_id']) ? $ebayConfig['entity_id'] : 0;
            $alreadyMapped = [];
            if ($viaListener) {
                $tempAvlImported = [];
            } else {
                $tempAvlImported = $this->importedTmpProduct->getCollection()->addFieldToFilter('item_type', 'product')
                    ->addFieldToFilter('rule_id', $ruleId)->getColumnValues('item_id');
                $alreadyMapped = $this->productMapRecord->getCollection()->addFieldToFilter('rule_id', $ruleId)
                    ->getColumnValues('ebay_pro_id');
                $tempAvlImported = array_merge($tempAvlImported, $alreadyMapped);
            }

            foreach ($resultsItems as $data) {
                $data = $this->jsonHelper->jsonDecode($this->jsonHelper->jsonEncode($data));
                if (in_array($data['ItemID'], $tempAvlImported)) {
                    continue;
                }

                if (!$this->helper->isDesWithHtml()) {
                    $data['Description'] = preg_replace('#<script(.*?)>(.*?)</script>#is', '', $data['Description']);
                    $data['Description'] = preg_replace('#<link(.*?)>(.*?)</link>#is', '', $data['Description']);
                    $data['Description'] = preg_replace('#<style(.*?)>(.*?)</style>#is', '', $data['Description']);
                    $data['Description'] = strip_tags($data['Description']);
                }

                $wholedata = $this->prepareWholeData($data, $ebayConfig);
                //set Specification in wholedata
                if ($this->helper->isProductWithSpeci()) {
                    $eBayClient = $this->helper->getEbayAPI($ebayConfig['entity_id']);
                    $specification = $this->getItemSpecification(
                        $data['ItemID'],
                        $ebayConfig['attribute_set_id'],
                        $eBayClient
                    );
                    if ($specification && is_array($specification)) {
                        $wholedata['specification'] = $specification;
                    }
                }
                $wholedata = $this->setImageData($wholedata, $data['PictureDetails']);
                /* Save imported product in temp table***/
                if ($viaListener) {
                    return $wholedata;
                } elseif (!$viaCron) {
                    $currentDate = $this->dateTime->date()->format('Y-m-d\TH:i:s');
                    $items[] = [
                        'item_type' => 'product',
                        'item_id' => $data['ItemID'],
                        'product_data' => $this->jsonHelper->jsonEncode($wholedata),
                        'created_at' => $currentDate,
                        'rule_id' => $ruleId,
                    ];
                } else {
                    $productId = $this->cronActionOnProductData($wholedata);
                    return $productId;
                }
            }
            if (!empty($items)) {
                return $this->helper->insertDataInBulk('wk_multiebay_tempebay', $items);
            }
            return 0;
        } catch (\Exception $error) {
            $this->logger->addError('manageProductRawData : ' . $error->getMessage());
            throw $error;
        }
    }

    /**
     * cronActionOnProductData
     * @param array $tempProData
     * @return int
     */

    private function cronActionOnProductData($tempProData) {
        try {
            $productId = 0;
            $request = $this->contextController->getRequest();
            if (($tempProData['type_id'] == 'simple') || (isset($tempProData['supperattr'])
                && empty($tempProData['supperattr']))) {
                if (isset($tempProData['assocate_pro'][0])) {
                    $tempProData['price'] = $tempProData['assocate_pro'][0]['price'];
                    $tempProData['stock'] = $tempProData['assocate_pro'][0]['qty'];
                    $tempProData['type_id'] = 'simple';
                    foreach ($tempProData['assocate_pro'][0] as $key => $value) {
                        if (strpos($key, 'conf_') !== false) {
                            $tempProData[$key] = $value;
                        }
                    }
                    unset($tempProData['assocate_pro']);
                    unset($tempProData['supperattr']);
                }
                foreach ($tempProData as $key => $value) {
                    $request->setParam($key, $value);
                }

                $result = $this->helper->saveSimpleProduct($request);
            } else {
                foreach ($tempProData as $key => $value) {
                    $request->setParam($key, $value);
                }
                $result = $this->helper->saveConfigProduct($request);
            }
            $data = [
                'ebay_pro_id' => $tempProData['ebay_item_id'],
                'name' => $tempProData['name'],
                'price' => $tempProData['price'],
                'product_type' => $tempProData['type_id'],
                'rule_id' => $this->helper->ruleId,
            ];

            if (isset($result['product_id']) && $result['product_id']) {
                $productId = $data['magento_pro_id'] = $result['product_id'];
                $data['mage_cat_id'] = $tempProData['category'][0];
                $record = $this->productMapRecord;
                $record->setData($data);
                $record->save();
            }
            $this->registry->unregister('product');
            $this->registry->unregister('current_product');
            $this->registry->unregister('current_store');
            return $productId;
        } catch (\Exception $e) {
            $this->logger->info('product raw data -' . $this->jsonHelper->jsonEncode($tempProData));
            $this->logger->addError('cronActionOnProductData :- ' . $e->getMessage());
            return $productId;
        }
    }

    /**
     * prepareWholeData
     * @param array $data
     * @param int $ruleId
     * @return array
     */
    private function prepareWholeData($data, $ebayConfig) {
        try {
            $managedProData = $this->getManageProductData($data, $ebayConfig);
            /* get product variation**/
            $productCost = $this->helper->getPriceAfterAppliedRule(
                $data['SellingStatus']['CurrentPrice']['_'],
                'import'
            );
            if (isset($data['Variations']) && !empty($data['Variations'])) {
                $itemSku = isset($data['SKU']) ? $data['SKU'] . '-' . $data['ItemID'] : $data['ItemID'];
                $superAttrAndAssociatePro = $this->getSuperAttrAndAssociatePro(
                    $data['Variations']['Variation'],
                    $itemSku,
                    $managedProData['weight']
                );

                $wholedata = [
                    'ebay_item_id' => $data['ItemID'],
                    'type_id' => 'configurable',
                    'supperattr' => $superAttrAndAssociatePro['super_att_ids'],
                    'status' => 1,
                    'attribute_set_id' => $managedProData['attribute_set_id'],
                    'category' => [$managedProData['ebay_mage_id']],
                    'name' => $data['Title'],
                    'description' => $data['Description'],
                    'short_description' => ' ',
                    'sku' => isset($data['SKU']) ? $data['SKU'] : $data['ItemID'],
                    'price' => $productCost['price'],
                    'price_rule' => $productCost['price_rule'],
                    'currency_id' => $data['SellingStatus']['CurrentPrice']['currencyID'],
                    'is_in_stock' => 1,
                    'tax_class_id' => 0,
                    'weight' => $managedProData['weight'],
                    'listing_status' => $data['SellingStatus']['ListingStatus'],
                ];

                /* Assigne values to store product according to eBay product**/
                foreach ($managedProData['pro_cat_spec'] as $key => $value) {
                    $wholedata[$key] = $value;
                }

                $wholedata['assocate_pro'] = $superAttrAndAssociatePro['associate_pro'];
            } else {
                /**For without variation product**/
                $wholedata = [
                    'ebay_item_id' => $data['ItemID'],
                    'type_id' => 'simple',
                    'status' => 1,
                    'attribute_set_id' => $managedProData['attribute_set_id'],
                    'producttypecustom' => 'customproductsimple',
                    'category' => [$managedProData['ebay_mage_id']],
                    'name' => $data['Title'],
                    'description' => $data['Description'],
                    'short_description' => ' ',
                    'sku' => isset($data['SKU']) ? $data['SKU'] . '-' . $data['ItemID'] : $data['ItemID'],
                    'price' => $productCost['price'],
                    'price_rule' => $productCost['price_rule'],
                    'currency_id' => $data['SellingStatus']['CurrentPrice']['currencyID'],
                    'stock' => $data['Quantity'],
                    'is_in_stock' => 1,
                    'tax_class_id' => 0,
                    'weight' => $managedProData['weight'],
                    'listing_status' => $data['SellingStatus']['ListingStatus'],
                ];
                foreach ($managedProData['pro_cat_spec'] as $key => $value) {
                    $wholedata[$key] = $value;
                }
            }
            return $wholedata;
        } catch (\Exception $e) {
            $this->logger->addError('prepareWholeData :- ' . $e->getMessage());
            return [];
        }
    }

    /**
     * getSuperAttrAndAssociatePro
     * @param array $variationsList
     * @param string $itemId
     * @param float $weight
     * @return arary
     */
    private function getSuperAttrAndAssociatePro($variationsList, $itemId, $weight) {
        try {
            $superAttIds = [];
            $associatePro = [];
            if (isset($variationsList[0]) === false) {
                $variationsList = [0 => $variationsList];
            }
            $count = 1;
            foreach ($variationsList as $variation) {
                $attributeData = [];
                $variationSpecifics = $variation['VariationSpecifics'];
                if (isset($variationSpecifics['NameValueList'])) {
                    if (isset($variationSpecifics['NameValueList']['Name'])) {
                        $variationSpecifics['NameValueList'] = [0 => $variationSpecifics['NameValueList']];
                    }
                    foreach ($variationSpecifics['NameValueList'] as $nameValue) {
                        $attributeCode = str_replace(' ', '_', $nameValue['Name']);
                        $attributeCode = preg_replace('/[^A-Za-z0-9\_]/', '', $attributeCode);
                        $mageAttrCode = substr('conf_' . strtolower($attributeCode), 0, 30);
                        if ($nameValue['Value'] != '' && $nameValue['Value'] != 'Non applicabile') {
                            $attributeData[$mageAttrCode] = $nameValue['Value'];
                            array_push($superAttIds, $mageAttrCode);
                        }
                    }
                }
                if (!empty($attributeData)) {
                    $quictProData = $this->getQuickProductData($variation, $attributeData, $itemId, $count, $weight);
                    array_push($associatePro, $quictProData);
                    $count++;
                }
            }
            $response = ['super_att_ids' => array_unique($superAttIds), 'associate_pro' => $associatePro];
            return $response;
        } catch (\Exception $error) {
            $this->logger->addError('getSuperAttrAndAssociatePro : ' . $error->getMessage());
            throw $error;
        }
    }

    /**
     * getQuickProductData
     * @param array $variation
     * @param array $attributeData
     * @param varchar $itemId
     * @param int $count
     * @param float $weight
     * @return array
     */
    private function getQuickProductData($variation, $attributeData, $itemId, $count, $weight) {
        try {
            if (isset($variation['StartPrice']) && isset($variation['StartPrice']['_'])) {
                $itemPrice = isset($variation['StartPrice']['_']) ?
                $variation['StartPrice']['_'] : $variation['StartPrice'];
                $currencyId = isset($variation['StartPrice']['currencyID']) ? $variation['StartPrice']['currencyID'] : '';
            } else {
                $itemPrice = isset($variation['_']) ? $variation['_'] : $variation['StartPrice'];
                $currencyId = isset($variation['currencyID']) ? $variation['currencyID'] : '';
            }

            $quictProData = [
                'status' => 1,
                'sku' => $itemId . '-' . $count,
                'price' => $itemPrice,
                'currency_id' => $currencyId,
                'qty' => (int) $variation['Quantity'] - (int) $variation['SellingStatus']['QuantitySold'],
                'is_in_stock' => (int) $variation['SellingStatus']['QuantitySold'] > 0 ? 1 : 0,
                'tax_class_id' => 0,
                'weight' => $weight,
                'visibility' => 1,
            ];

            foreach ($attributeData as $mageAttrCode => $value) {
                $quictProData[$mageAttrCode] = $this->getAttributeOptionId($mageAttrCode, $value);
            }
            return $quictProData;
        } catch (\Exception $error) {
            $this->getError('getQuickProductData : ' . $error->getMessage());
            throw $error;
        }
    }

    /**
     * getAttribute
     * @param string $mageAttrCode
     * @param string $value
     * @return int
     */
    private function getAttributeOptionId($mageAttrCode, $value) {
        try {
            $attributeInfo = $this->attributeModel->create()->getCollection()
                ->addFieldToFilter('attribute_code', $mageAttrCode)
                ->setPageSize(1)->getFirstItem();
            $attribute = $this->attributeModel->create()->load($attributeInfo->getAttributeId());
            return $attribute->getSource()->getOptionId($value);
        } catch (\Exception $e) {
            $this->logger->info('getSuperAttrIds ' . $e->getMessage());
        }
    }

    /**
     * manageProductData
     * @param array $data
     * @param array $ebayConfig
     */
    private function getManageProductData($data, $ebayConfig) {
        try {
            $proCatSpec = [];
            $ebayCatId = $data['PrimaryCategory']['CategoryID'];
            $catMapData = $this->helper->getStoreBayCatMapData($ebayCatId, $ebayConfig['entity_id']);
            $eBayMageId = $catMapData ? $catMapData->getMageCatId() : $ebayConfig['default_cate'];
            //Custom Code
            $catMapData_2 = false;
            if (isset($data['SecondaryCategory']) && isset($data['SecondaryCategory']['CategoryID'])) {
                $ebayCatId_2 = $data['SecondaryCategory']['CategoryID'];
                $catMapData_2 = $this->helper->getStoreBayCatMapData($ebayCatId_2, $ebayConfig['entity_id']);
            }
            $eBayMageId_2 = $catMapData_2 ? $catMapData_2->getMageCatId() : $ebayConfig['default_cate'];

            if (isset($data['Variations'])) {
                $attr = $this->helper->createSuperAttrMagento($data['Variations'], $ebayConfig['attribute_set_id']);
            }

            /* get Conditional attribute of product*/
            if (isset($data['ConditionID']) && $data['ConditionID']) {
                $label = $data['ConditionID'] . ' for ' . $data['ConditionDisplayName'];
                $ebayCatName = explode(':', $data['PrimaryCategory']['CategoryName']);
                $ebayCatName = intval($ebayCatName[count($ebayCatName) - 1]) == 0 ?
                $ebayCatName[count($ebayCatName) - 1] : $ebayCatName[count($ebayCatName) - 2];
                $mageAttrCode = $this->helper->createProConditionAttr(
                    [$label],
                    $ebayCatName,
                    $ebayConfig['attribute_set_id']
                );
                $conditionAttr = $this->helper->getAttributeOptValue($mageAttrCode, $label);
                $proCatSpec[$mageAttrCode] = $conditionAttr['value'];
            }

            /**get Weight of product **/
            $weight = 0;
            if (isset($data['ShippingDetails']['CalculatedShippingRate'])
                && is_array($data['ShippingDetails']['CalculatedShippingRate'])) {
                foreach ($data['ShippingDetails']['CalculatedShippingRate'] as $weightData) {
                    if (isset($weightData['unit']) && $weightData['unit'] == 'lbs') {
                        $weight = $weightData['_'];
                    } elseif (isset($data['ShippingDetails']['CalculatedShippingRate']['any'])) {
                        preg_match(
                            "/<WeightMajor[^>]*>(.*?)<\\/WeightMajor>/si",
                            $data['ShippingDetails']['CalculatedShippingRate']['any'],
                            $match
                        );
                        $weight = $match[1];
                    }
                }
            }

            $responce = [
                'ebay_mage_id' => $eBayMageId . ',' . $eBayMageId_2,
                'pro_cat_spec' => $proCatSpec,
                'weight' => $weight ? $weight : 1,
                'attribute_set_id' => $ebayConfig['attribute_set_id'],
            ];

            return $responce;
        } catch (\Exception $error) {
            $this->logger->addError('getManageProductData: ' . $error->getMessage());
            throw $error;
        }
    }

    /**
     * setImageData
     * @param array $wholedata
     * @param array $pictureDetails
     * @return array
     */
    private function setImageData($wholedata, $pictureDetails) {
        try {
            $imageArr = [];
            $defaultImage = '';
            $i = 0;
            $path = BP . '/pub/media/import/multiebaystoremageconnect/';
            if (!is_dir($path)) {
                mkdir($path, 0755, true);
            }

            if ($pictureDetails['PhotoDisplay'] != 'None' && isset($pictureDetails['PictureURL'])) {
                if (!is_array($pictureDetails['PictureURL'])) {
                    if ($i == 0) {
                        $defaultImage = $pictureDetails['PictureURL'];
                        $i++;
                    }
                    array_push($imageArr, $pictureDetails['PictureURL']);
                } else {
                    foreach ($pictureDetails['PictureURL'] as $value) {
                        if ($i == 0) {
                            $defaultImage = $value;
                            $i++;
                        }
                        array_push($imageArr, $value);
                    }
                }
                $wholedata['image_data'] = ['default' => $defaultImage, 'images' => $imageArr];
            }
            return $wholedata;
        } catch (\Exception $error) {
            $this->logger->addError('setImageData : ' . $error->getMessage());
            return $wholedata;
        }
    }

    /**
     * getItemSpecification
     * @param strint $itemId
     * @param int $attributeSetId
     * @param Ebay\eBaySOAP $client
     * @return array|false
     */
    private function getItemSpecification($itemId, $attributeSetId = 0, $client) {
        try {
            $params = [
                'Version' => 659,
                'DetailLevel' => 'ReturnAll',
                'ItemID' => $itemId,
                'IncludeItemSpecifics' => true,
            ];

            $results = $client->GetItem($params);

            if (isset($results->Ack) && $results->Ack == 'Success') {
                if (isset($results->Item->ItemSpecifics->NameValueList)) {
                    $specification = $results->Item->ItemSpecifics->NameValueList;
                    $specification = $this->jsonHelper->jsonDecode($this->jsonHelper->jsonEncode($specification));
                    $specification = isset($specification[0]) ? $specification : [0 => $specification];
                    $specification = $this->helper->createProSpecificationAttribute($specification, $attributeSetId);
                    return $specification;
                }
            }
            return false;
        } catch (\Exception $e) {
            $this->logger->addError('getItemSpecification Error :- ' . $e->getMessage());
            return false;
        }
    }
    
    /**
     * getTotalShippingAndTaxAmount
     * @param array $transaction
     * @return array
     */
    private function getTotalShippingAndTaxAmount($transaction)
    {
        $tranData = [
            'shipPrice' => 0,
            'totalTax' => 0,
            'firstname' => '',
            'lastname' => ''
        ];
        if (isset($transaction['ActualShippingCost']['_'])) {
            $tranData['shipPrice'] = $tranData['shipPrice'] + floatval($transaction['ActualShippingCost']['_']);
        }
        if (isset($transaction['ActualHandlingCost']['_'])) {
            $tranData['shipPrice'] = $tranData['shipPrice'] + floatval($transaction['ActualHandlingCost']['_']);
        }
        if (isset($transaction['Taxes']['TotalTaxAmount']['_'])) {
            $tranData['totalTax'] = $tranData['totalTax'] + $transaction['Taxes']['TotalTaxAmount']['_'];
        }
        return $tranData;
    }
}
