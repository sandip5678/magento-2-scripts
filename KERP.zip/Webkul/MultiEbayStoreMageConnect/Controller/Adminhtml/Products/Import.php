<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Products;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Session\SessionManagerInterface as CoreSession;
use Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Products;

class Import extends Products
{
    /**
     * @var int
     */
    private $ruleId;

    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData
     */
    private $manageRawDataHelper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param TimezoneInterface $dateTime
     * @param CoreSession $coreSession,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData $manageRawDataHelper
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        TimezoneInterface $dateTime,
        CoreSession $coreSession,
        \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData $manageRawDataHelper,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->dateTime = $dateTime;
        $this->coreSession = $coreSession;
        $this->manageRawDataHelper = $manageRawDataHelper;
        $this->logger = $helper->getLogger();
        $this->helper = $helper;
    }

    /**
     * Mapped Product List page.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('multiebaystoremageconnect/*/');
            return;
        }
        try {
            $validatedData = $this->validateData();
            if ($validatedData['validation_pass']) {
                $items = 0;
                $responce = [];
                $errorMsg = '';
                $ruleId = $this->getRequest()->getParam('id');
                $validatedData['client'] = $this->helper->getEbayAPI($ruleId);
                $importStatus = $this->_getProductImportType($validatedData['ebay_config']);
                $totalImported = true;
                if (empty($importStatus['import_type'])) {
                    if (empty($importStatus['error_msg'])) {
                        $responce= $this->_callGetSellerList($validatedData, $validatedData['category']);
                        /*foreach ($importStatus['data'] as $mappedRecord) {
                            $categoryPages = $this->coreSession->getCategoryPages();
                            $totalPage = isset($categoryPages[$mappedRecord['ebay_cat_id']]) ?
                                                $categoryPages[$mappedRecord['ebay_cat_id']] : 0;
                            if ($totalPage >= $validatedData['page'] || empty($categoryPages)
                                || !isset($categoryPages[$mappedRecord['ebay_cat_id']])) {
                                $newItems = $this->_callGetSellerList($validatedData, $mappedRecord['ebay_cat_id']);
                                if (isset($newItems['total_imported']) && $newItems['total_imported'] == false) {
                                    $totalImported = false;
                                }
                                if (empty($newItems['error_msg']) && !empty($newItems['data'])) {
                                    $items = $items+$newItems['data'];
                                } elseif ($newItems['error_msg']) {
                                    $errorMsg = $newItems['error_msg'];
                                }
                            }
                        }*/
                    } else {
                        $responce = [
                            'data' => '',
                            'error_msg' => $importStatus['error_msg'],
                            'total_products' => 0,
                            'total_imported' => $totalImported
                        ];
                    }
                    /*$totalImported ? $this->coreSession->unsCategoryPages() : '';
                    $responce = [
                        'data' => $items,
                        'error_msg' => $errorMsg,
                        'total_products' => $items,
                        'total_imported' => $totalImported
                    ];*/
                } else {
                    $responce = $this->_callGetSellerList($validatedData);
                }
            } else {
                $responce = ['data' => '','error_msg' => $validatedData['error_msg']];
            }
        } catch (\Exception $e) {
            $this->logger->addError($e->getMessage());
            $responce = ['data' => $items,'error_msg' => $e->getMessage()];
        }
        return $this->resultJsonFactory->create()->setData($responce);
    }

    /**
     * get product import type status
     *
     * @return array
     */
    private function _getProductImportType($ebayConfiguration)
    {
        $errorMsg = false;
        $importType = null;
        $data = null;
        if (isset($ebayConfiguration['import_product']) && empty($ebayConfiguration['import_product'])) {
            $mappedCategoryColl = $this->helper->getMappedCategoryData($ebayConfiguration['entity_id']);
            if (empty($mappedCategoryColl)) {
                $errorMsg = __('You haven\'t mapped any ebay category(s).');
            } else {
                $data = $mappedCategoryColl['items'];
            }
            $importType = 0;
        } else {
            $importType = 1;
        }
        return ['data' => $data, 'error_msg' => $errorMsg, 'import_type' => $importType];
    }

    /**
     * intract with ebay api
     *
     * @param array $validatedData
     * @return array
     */
    private function _callGetSellerList($validatedData, $categoryId = null)
    {
        try {
            $items = 0;
            $params = [
                'Version' => 849, //version
                'IncludeVariations' => true,
                'UserID' => $validatedData['ebay_config']['ebayuserid'],
                'DetailLevel' => 'ReturnAll',
                'Pagination' => [
                    'EntriesPerPage' => '100',
                    'PageNumber' => ($validatedData['page'] ? $validatedData['page'] : 1)
                ],
                'StartTimeFrom' => $validatedData['end_time_from'],
                'StartTimeTo' => $validatedData['end_time_to'],
            ];

            if (!empty($categoryId)) {
                $params['CategoryID'] = $categoryId;
            }
            $client = $validatedData['client'];
            $results = $client->GetSellerList($params);
            /*if (!empty($categoryId)) {
                $categoryPages = $this->coreSession->getCategoryPages();
                $categoryPages[$categoryId] = isset($results->PaginationResult->TotalNumberOfPages) ?
                                    $results->PaginationResult->TotalNumberOfPages : null;
                $this->coreSession->setCategoryPages($categoryPages);
            }*/

            if (isset($results->ItemArray->Item)) {
                $ebayItemObject = $results->ItemArray->Item;
                if (count($results->ItemArray->Item) == 1) {
                    $ebayItemObject = [0 => $results->ItemArray->Item];
                }

                $items = $this->manageRawDataHelper->manageProductRawData(
                    $ebayItemObject,
                    $validatedData['ebay_config']
                );
                $responce = ['data' => $items, 'error_msg' => false, 'total_products' => $items];
                $responce['total_imported'] = $results->ReturnedItemCountActual == 100 ? false : true;

            } else {
                if (isset($results->Ack) && $results->Ack == 'Success') {
                    $errorMsg = empty($items) ? __('There are no products in your eBay account') : '';
                    $responce = ['data' => $items, 'error_msg' => $errorMsg];
                } elseif (isset($results->detail->FaultDetail->DetailedMessage)) {
                    $errorMsg =  $results->detail->FaultDetail->DetailedMessage;
                    $responce = ['data' => $items, 'error_msg' => $errorMsg];
                } else {
                    $errorMsg = isset($results->Errors->LongMessage) ? $results->Errors->LongMessage :
                                                __("Invalid response from eBay");
                    $responce = ['data' => $items, 'error_msg' => $errorMsg];
                }
            }
            return $responce;
        } catch (\Exception $e) {
            throw new \Exception($e->getMessage());
        }
    }

    /**
     * validateData
     * @return array
     */
    private function validateData()
    {
        try {
            if ($this->getRequest()->isPost()) {
                $ruleId = $this->getRequest()->getParam('id');
                $eBayConfig = $this->helper->geteBayConfiguration($ruleId);
                if ($eBayConfig) {
                    $postData = $this->getRequest()->getPost();
                    $endTimeFrom = $postData['from_date'] ? $postData['from_date'] : '';
                    $endTimeTo = $postData['from_to'] ? $postData['from_to'] : '';

                    $dt = $this->dateTime->date($endTimeFrom);
                    $endTimeFrom = $dt->format('Y-m-d\TH:i:s');
                    if ($endTimeTo) {
                        $dt = $this->dateTime->date($endTimeTo);
                    } else {
                        $dt->modify('+119 day');
                    }
                    $endTimeTo = $dt->modify('+23 hour +59 minutes +59 seconds')->format('Y-m-d\TH:i:s');
                    $responce = [
                        'validation_pass' => 1,
                        'ebay_config' => $eBayConfig,
                        'end_time_from' => $endTimeFrom,
                        'end_time_to' => $endTimeTo,
                        'page' => $postData['page'],
                        'category' => $postData['category'],
                        'only_active' => $postData['only_active'] == 'true' ? true : false
                    ];
                } else {
                    $responce = ['validation_pass' => 0, 'error_msg' => __('eBay configuration details are not saved')];
                }
            } else {
                $responce = ['validation_pass' => 0,'error_msg' => 'invalid request'];
            }
            return $responce;
        } catch (\Exception $e) {
            $this->logger->addError('Products import validatedata '.$e->getMessage());
            return ['validation_pass' => 0,'error_msg' => $e->getMessage()];
        }
    }
}
