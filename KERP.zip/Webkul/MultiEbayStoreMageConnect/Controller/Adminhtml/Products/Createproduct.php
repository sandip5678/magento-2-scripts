<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Products;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Webkul\MultiEbayStoreMageConnect\Api\ImportedtmpproductRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Products;

class Createproduct extends Products
{
    /**
     * @var ImportedtmpproductRepositoryInterface
     */
    private $importedTmpProductRepository;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @var \Magento\Backend\Model\Session
     */
    private $backendSession;

    /**
     * @param Context $context,
     * @param ImportedtmpproductRepositoryInterface $importedTmpProductRepository,
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
     */
    public function __construct(
        Context $context,
        ImportedtmpproductRepositoryInterface $importedTmpProductRepository,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
    ) {
        parent::__construct($context);
        $this->importedTmpProductRepository = $importedTmpProductRepository;
        $this->helper = $helper;
        $this->jsonHelper = $helper->getJsonHelper();
        $this->logger = $helper->getLogger();
        $this->resultJsonFactory = $resultJsonFactory;
        $this->backendSession = $context->getSession();
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            $ruleId = $this->getRequest()->getParam('ruleId');
            $tempData = $this->importedTmpProductRepository->getCollectionByProductTypeAndRuleId('product', $ruleId)
                                   ->setPageSize(1)->getFirstItem();
            $this->helper->geteBayConfiguration($ruleId);
            $this->backendSession->setEbaySession('start');
            $request = $this->getRequest();
            if ($tempData->getEntityId()) {
                $tempProData = $this->jsonHelper->jsonDecode($tempData->getProductData());
                $result = $this->processedTempDataToCreatePro($tempProData, $request);
                $data = [
                    'ebay_pro_id' => $tempData->getItemId(),
                    'name' => $tempProData['name'],
                    'price' => $tempProData['price'],
                    'price_rule' => $tempProData['price_rule'],
                    'product_type' => $tempProData['type_id'],
                    'rule_id'   => $ruleId
                ];
                $conditionAttr =  current(preg_grep('/^ebay_cond_/', array_keys($tempProData)));
                if ($conditionAttr) {
                    $data['condition_attribute'] = $conditionAttr;
                }
                if (isset($result['product_id']) && $result['product_id']) {
                    $data['magento_pro_id'] = $result['product_id'];
                    $data['mage_cat_id'] = $tempProData['category'][0];
                    $this->helper->insertDataInBulk('wk_multiebaysynchronize_product', [$data]);
                }
                $tempData->delete();
            } else {
                $data = $this->getRequest()->getParams();
                $total = (int) $data['count'] - (int) $data['skip'];
                $msg = '<div class="wk-mu-success wk-mu-box">'.__('Total ').$total.__(' Product(s) Imported.').'</div>';
                $msg .= '<div class="wk-mu-note wk-mu-box">'.__('Finished Execution.').'</div>';
                $result['msg'] = $msg;
            }
            $this->backendSession->unsEbaySession();
        } catch (\Exception $e) {
            $this->logger->addError('Controller Products CreateProduct : '.$e->getMessage());
            $result = [
                'error' => 1,
                'msg' => __('Something went wrong, Please check error log.'),
                'actual_error' => $e->getMessage()
            ];
        }
        $resultJson = $this->resultJsonFactory->create();
        return $resultJson->setData($result);
    }

    /**
     * process temp data to create eBay product
     *
     * @param array $tempProData
     * @param Object $request
     * @return array
     */
    public function processedTempDataToCreatePro($tempProData, $request)
    {
        try {
            $result = [];
            if (($tempProData['type_id'] == 'simple') || (isset($tempProData['supperattr'])
                && empty($tempProData['supperattr']))) {
                if (isset($tempProData['assocate_pro'][0])) {
                    $tempProData['price'] = $tempProData['assocate_pro'][0]['price'];
                    $tempProData['stock'] = $tempProData['assocate_pro'][0]['qty'];
                    $tempProData['type_id'] = 'simple';
                    foreach ($tempProData['assocate_pro'][0] as $key => $value) {
                        if (strpos($key, 'conf_') !== false) {
                            $tempProData[$key] = $value;
                        }
                    }
                    unset($tempProData['assocate_pro']);
                    unset($tempProData['supperattr']);
                }

                foreach ($tempProData as $key => $value) {
                    $request->setParam($key, $value);
                }
                $result = $this->helper->saveSimpleProduct($request);
            } else {
                foreach ($tempProData as $key => $value) {
                    $request->setParam($key, $value);
                }
                $result = $this->helper->saveConfigProduct($request);
            }
            return $result;
        } catch (\Exception $error) {
            $this->logger->addError('processedTempDataToCreatePro : '. $error->getMessage());
            echo $error->getMessage();
            //throw $error;
        }
    }
}
