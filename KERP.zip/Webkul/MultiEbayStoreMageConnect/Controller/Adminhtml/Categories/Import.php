<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Categories;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Categories;

class Import extends Categories
{
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Model\EbaycategoryFactory
     */
    private $ebaycategoryFactory;

    /**
     * @param Context $context,
     * @param JsonFactory $resultJsonFactory,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
     * @param \Webkul\MultiEbayStoreMageConnect\Model\EbaycategoryFactory $ebaycategoryFactory
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
        \Webkul\MultiEbayStoreMageConnect\Model\EbaycategoryFactory $ebaycategoryFactory
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->helper = $helper;
        $this->ebaycategoryFactory = $ebaycategoryFactory;
    }

    /**
     * eBay Category Sync Controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            $resultJson = $this->resultJsonFactory->create();
            $eBayConfig = $this->helper->geteBayConfiguration();
            $client = $this->helper->getEbayAPI();
            if ($client) {
                $params = [
                    'Version' => 853,
                    'SiteID' => 0,
                    'CategorySiteID' => $eBayConfig['globalsites'],
                    'LevelLimit' => 5,
                    'ViewAllNodes' => true,
                    'DetailLevel' => 'ReturnAll',
                ];
                $results = $client->GetCategories($params);
                $storedEbayCates = $this->ebaycategoryFactory->create()->getCollection()
                                        ->getColumnValues('ebay_cat_id');
                if (isset($results->CategoryArray->Category)) {
                    $ebayAllCategories = [];
                    foreach ($results->CategoryArray->Category as $value) {
                        if (!in_array($value->CategoryID, $storedEbayCates)) {
                            $ebayAllCategories[] = [
                                'ebay_cat_id'       => $value->CategoryID,
                                'ebay_cat_parentid' => $value->CategoryParentID,
                                'ebay_cat_name'     => $value->CategoryName
                            ];
                        }
                    }
                    if (!empty($ebayAllCategories)) {
                        $totalInsert = $this->helper->insertDataInBulk('wk_multiebay_categories', $ebayAllCategories);
                        $msg = $totalInsert.__(' eBay Categories imported successfully.');
                    } else {
                        $msg = __('No new ebay categories found.');
                    }
                    $result['success'] = __($msg);
                } else {
                    $result['msg'] = (isset($results->detail) && !empty($results->detail)) ?
                                        $results->detail->FaultDetail->DetailedMessage :
                                        __('Error in configurations.');
                }
            } else {
                $result['msg'] = __('Please fill all ebay details in configuration.');
            }
            return $resultJson->setData($result);
        } catch (\Exception $e) {
            $result['msg'] = $e->getMessage();
            return $resultJson->setData($result);
        }
    }
}
