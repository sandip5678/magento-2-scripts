<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Ebayorder;

use Magento\Backend\App\Action\Context;
use Webkul\MultiEbayStoreMageConnect\Api\ImportedtmpproductRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Api\OrdermapRepositoryInterface;
use Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Ebayorder;

class Createorder extends Ebayorder {
    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Model\Ordermap
     */
    private $orderMapRecord;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helperData;

    /**
     * @var OrdermapRepositoryInterface
     */
    private $orderMapRepository;

    /**
     * @var ImportedtmpproductRepositoryInterface
     */
    private $importedTmpProductRepository;

    /**
     * @param Context                                          $context
     * @param \Webkul\MultiEbayStoreMageConnect\Model\Ordermap $orderMapRecord
     * @param OrdermapRepositoryInterface                      $orderMapRepository
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data    $helperData
     * @param ImportedtmpproductRepositoryInterface            $importedTmpProductRepository
     */
    public function __construct(
        Context $context,
        \Webkul\MultiEbayStoreMageConnect\Model\Ordermap $orderMapRecord,
        OrdermapRepositoryInterface $orderMapRepository,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helperData,
        ImportedtmpproductRepositoryInterface $importedTmpProductRepository
    ) {
        parent::__construct($context);
        $this->orderMapRecord = $orderMapRecord;
        $this->helperData = $helperData;
        $this->orderMapRepository = $orderMapRepository;
        $this->importedTmpProductRepository = $importedTmpProductRepository;
        $this->logger = $helperData->getLogger();
        $this->jsonHelper = $helperData->getJsonHelper();
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute() {
        try {
            $ruleId = $this->getRequest()->getParam('ruleId');
            //$this->helperData->getEbayAPI($ruleId);
            $tempData = $this->importedTmpProductRepository->getCollectionByProductTypeAndRuleId('order', $ruleId)
                ->setPageSize(1)->getFirstItem();
            if ($tempData->getEntityId()) {
                $tempOrder = $this->jsonHelper->jsonDecode($tempData->getProductData());
                $mapedOrder = $this->orderMapRepository->getRecordByEbayOrderId($tempOrder['ebay_order_id'])
                    ->setPageSize(1)->getFirstItem();

                if (!$mapedOrder->getEntityId()) {
                    //Create order in stor as eBay
                    $result = $this->helperData->createMageOrder($tempOrder, $ruleId);
                    if (isset($result['order_id']) && $result['order_id']) {
                        $data = [
                            'ebay_order_id' => $tempOrder['ebay_order_id'],
                            'mage_order_id' => $result['order_id'],
                            'status' => $tempOrder['order_status'],
                            'rule_id' => $ruleId,
                        ];
                        $record = $this->orderMapRecord;
                        $record->setData($data)->save();
                    }
                } else {
                    $result = [
                        'error' => 1,
                        'msg' => __('eBay order ') . $tempOrder['ebay_order_id'] . __(' already mapped with store order #')
                        . $mapedOrder->getMageOrderId(),
                    ];
                }
                $tempData->delete();
            } else {
                $data = $this->getRequest()->getParams();
                $total = (int) $data['count'] - (int) $data['skip'];
                $msg = '<div class="wk-mu-success wk-mu-box">' . __('Total ') . $total . __(' Order(s) Imported.') . '</div>';
                $msg .= '<div class="wk-mu-note wk-mu-box">' . __('Finished Execution.') . '</div>';
                $result['msg'] = $msg;
            }
        } catch (\Exception $e) {
            $this->logger->addError('Controller Ebayorder createOrder : ' . $e->getMessage());
            $result = [
                'error' => 1,
                'msg' => __('Something went wrong, Please check error log.'),
                'actual_error' => $e->getMessage(),
            ];
        }
        $this->getResponse()->representJson($this->jsonHelper->jsonEncode($result));
    }
}
