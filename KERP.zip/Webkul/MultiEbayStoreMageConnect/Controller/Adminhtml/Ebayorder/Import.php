<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Ebayorder;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Webkul\MultiEbayStoreMageConnect\Controller\Adminhtml\Ebayorder;

class Import extends Ebayorder {
    /**
     * @var JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    private $timezone;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData
     */
    private $manageDataHelper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param Magento\Framework\Stdlib\DateTime\TimezoneInterface $timezone,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData $manageDataHelper
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        TimezoneInterface $timezone,
        \Webkul\MultiEbayStoreMageConnect\Helper\ManageRawData $manageDataHelper,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->timezone = $timezone;
        $this->manageDataHelper = $manageDataHelper;
        $this->logger = $helper->getLogger();
        $this->jsonHelper = $helper->getJsonHelper();
        $this->helper = $helper;
    }

    /**
     * eBay order import controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute() {
        $notifications = [];
        $data = $this->getRequest()->getPostValue();
        if (!$data) {
            $this->_redirect('multiebaystoremageconnect/*/');
            return;
        }
        try {
            $validateData = $this->validateRequest();
            $ruleId = $this->getRequest()->getParam('id');
            $eBayClient = $this->helper->getEbayAPI($ruleId);
            if ($validateData['valid_request'] && $eBayClient) {
                $items = 0;
                $responce = [];
                $tmpWholeData = [];
                // import data from ebay
                $pagenumber = $validateData['page'];
                $params = [
                    'Version' => 891,
                    'DetailLevel' => 'ReturnAll',
                    'Pagination' => [
                        'EntriesPerPage' => '100',
                        'PageNumber' => ($pagenumber ? $pagenumber : 1),
                    ],
                    'CreateTimeFrom' => $validateData['create_time_from'],
                    'CreateTimeTo' => $validateData['create_time_to'],
                    'OrderStatus' => 'Completed',
                ];
                $results = $eBayClient->GetOrders($params);
                if (isset($results->OrderArray->Order)) {
                    $eBayOrders = $this->jsonHelper->jsonDecode(
                        $this->jsonHelper->jsonEncode($results->OrderArray->Order)
                    );
                    $eBayOrders = isset($eBayOrders[0]) ? $eBayOrders : [0 => $eBayOrders];
                    $notifications = $this->manageDataHelper->manageOrderRawData($eBayOrders, $ruleId);
                    $items = $items + count($notifications['items']);
                    $responce = [
                        'data' => $items,
                        'error_msg' => false,
                        'total_order' => $notifications['items'],
                        'total_imported' => $results->ReturnedOrderCountActual == 100 ? false : true,
                        'notification' => $notifications['errorMsg'],
                        'totalPage' => $results->PaginationResult->TotalNumberOfPages,
                    ];
                } else {
                    if (isset($results->Ack) && $results->Ack != 'Success') {
                        $responce = [
                            'data' => $notifications['items'],
                            'error_msg' => $results->Errors->LongMessage,
                        ];
                    } else {
                        $responce = ['data' => '', 'error_msg' => false, 'notification' => '', 'total_imported' => true];
                    }
                }
            } else {
                $responce = ['data' => '', 'error_msg' => $validateData['error_msg']];
            }
        } catch (\Exception $e) {
            $responce = ['data' => '', 'error_msg' => $e->getMessage()];
        }
        return $this->resultJsonFactory->create()->setData($responce);
    }

    /**
     * validateRequest
     * @return array
     */
    private function validateRequest() {
        try {
            if ($this->getRequest()->isPost()) {
                $postData = $this->getRequest()->getPost();
                $ruleId = $this->getRequest()->getParam('id');
                $eBayConfig = $this->helper->geteBayConfiguration($ruleId);
                if ($eBayConfig) {
                    $endTimeFrom = $postData['from_date'] ? $postData['from_date'] : '';
                    $endTimeTo = $postData['from_to'] ? $postData['from_to'] : '';
                    $dt = $this->timezone->date($endTimeFrom);
                    $endTimeFrom = $dt->format('Y-m-d\TH:i:s');
                    if ($endTimeTo) {
                        $dt = $this->timezone->date($endTimeTo);
                    } else {
                        $dt->modify('+90 day');
                    }
                    $endTimeTo = $dt->modify('+23 hour +59 minutes +59 seconds')->format('Y-m-d\TH:i:s');
                    $responce = [
                        'valid_request' => 1,
                        'page' => $postData['page'],
                        'ebay_config' => $eBayConfig,
                        'create_time_from' => $endTimeFrom,
                        'create_time_to' => $endTimeTo,
                    ];
                } else {
                    $responce = ['valid_request' => 0, 'error_msg' => __('eBay configuration details are not saved.')];
                }
            } else {
                $responce = ['valid_request' => 0, 'error_msg' => 'invalid request'];
            }
            return $responce;
        } catch (\Exception $e) {
            $this->logger->addError('Ebayorder Import' . $e->getMessage());
            return ['valid_request' => 0, 'error_msg' => $e->getMessage()];
        }
    }

}
