#Installation

Magento2 Multi eBay connector module installation is very easy, please follow the steps for installation-

1. Unzip the respective extension zip and then move "app" folder (inside "src" folder) into magento root directory.

Run Following Command via terminal
-----------------------------------
php bin/magento setup:upgrade

2. Flush the cache and reindex all.

now module is properly installed

#User Guide

For Multi eBay connector module's working process follow user guide - http://webkul.com/blog/multi-ebay-account-connector-for-magento2/

#Support

Find us our support policy - https://store.webkul.com/support.html/

#Refund

Find us our refund policy - https://store.webkul.com/refund-policy.html/

----------------------------------------------------------------------------------------
Note - This readme file is strictly need to use when you have purchased the software from 
webkul store i.e https://store.webkul.com . If you purchase the module from magento marketplace 
connect this readme file will not work.


