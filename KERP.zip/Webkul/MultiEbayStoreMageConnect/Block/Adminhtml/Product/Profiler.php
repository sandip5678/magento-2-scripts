<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Block\Adminhtml\Product;

class Profiler extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Webkul\Ebaymagentoconnect\Helper\Data
     */
    private $helperData;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Webkul\Ebaymagentoconnect\Helper\Data $helperData
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helperData,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helperData = $helperData;
    }

    /**
     * For get total imported product count.
     * @return int
     */
    public function getImportedProduct()
    {
        $ruleId = $this->getRequest()->getParam('id');
        return $this->helperData->getTotalImportedCount('product', $ruleId);
    }

    /**
     * For getMappedCategories count.
     * @return int
     */
    public function getMappedCategories()
    {
        $cates = [];
        $ruleId = $this->getRequest()->getParam('id');
        $mappedCatesArray =  $this->helperData->getMappedCategoryData($ruleId);
        if (count($mappedCatesArray['items'])) {
            foreach ($mappedCatesArray['items'] as $record) {
                $cates[] = $record['ebay_cat_id'];
            }
        }

        $configs = $this->helperData->geteBayConfiguration($ruleId)['import_product'];
        return ['isAllProImport' => $configs, 'cates' => implode(',', $cates)];
    }
}
