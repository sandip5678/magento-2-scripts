<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Block\Adminhtml\Product;

use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class ProductImportIneBay extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    private $productCollectionFactory;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param CollectionFactory $productCollectionFactory
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        CollectionFactory $productCollectionFactory,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->productCollectionFactory = $productCollectionFactory;
    }

    /**
     * For get selected mage product count.
     * @return int
     */
    public function getProductsListForImportIneBay()
    {
        $params = $this->getRequest()->getParams();
        if (isset($params['mageProEntityIds'])) {
            $mageProCollection = $this->productCollectionFactory->create()
                                        ->addFieldToFilter('entity_id',['in'=>$params['mageProEntityIds']])
                                        ->getColumnValues('entity_id');
            return $mageProCollection;
        } else {
            return [];
        }
    }
}
