<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Block\Adminhtml\Ebayaccount\Edit\Tab;

use Magento\Backend\Block\Widget\Grid;
use Magento\Backend\Block\Widget\Grid\Column;
use Magento\Backend\Block\Widget\Grid\Extended;
use Webkul\MultiEbayStoreMageConnect\Model\ProductmapFactory;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;

class MageProductGrid extends \Magento\Backend\Block\Widget\Grid\Extended
{
    /**
     * @var \Magento\Catalog\Model\Product\Visibility
     */
    private $productVisibility;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
     */
    private $productCollection;

    /**
     * @var ProductmapFactory
     */
    private $productMap;

    /**
     * @param \Magento\Backend\Helper\Data $backendHelper,
     * @param \Magento\Backend\Block\Template\Context $context,
     * @param \Magento\Catalog\Model\Product\Visibility $productVisibility,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
     * @param CollectionFactory $productCollection,
     * @param ProductmapFactory $productMap,
     * @param array $data = []
     */
    public function __construct(
        \Magento\Backend\Helper\Data $backendHelper,
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Catalog\Model\Product\Visibility $productVisibility,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
        CollectionFactory $productCollection,
        ProductmapFactory $productMap,
        array $data = []
    ) {
        $this->productVisibility = $productVisibility;
        $this->helper = $helper;
        $this->productCollection = $productCollection;
        $this->productMap = $productMap;
        parent::__construct($context, $backendHelper, $data);
    }

    /**
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('mage_map_product');
        $this->setDefaultSort('id');
        $this->setUseAjax(true);
    }

    /**
     * @return Grid
     */
    protected function _prepareCollection()
    {
        $id = $this->getRequest()->getParam('id');
        $sellerConfig = $this->helper->geteBayConfiguration($id);
        $mappedProIds = $this->productMap->create()->getCollection()->addFieldToFilter('rule_id', $id)
                                                    ->getColumnValues('magento_pro_id');
        $productTypeAllowed = explode(',', $sellerConfig['product_type_allowed']);
        $mageProCollection = $this->productCollection->create()->addAttributeToSelect('*')
                                    ->addFieldToFilter('type_id', ['in' => $productTypeAllowed]);
        if (!empty($mappedProIds)) {
            $mageProCollection->addFieldToFilter('entity_id', ['nin' => $mappedProIds]);
        }
        $mageProCollection->setVisibility($this->productVisibility->getVisibleInSiteIds());
        $this->setCollection($mageProCollection);
        return parent::_prepareCollection();
    }

    /**
     * @return Extended
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            'entity_id',
            [
                'header' => __('Id'),
                'sortable' => true,
                'index' => 'entity_id',
                'header_css_class' => 'col-id',
                'column_css_class' => 'col-id'
            ]
        );
        $this->addColumn(
            'name',
            [
                'header' => __('Name'),
                'sortable' => true,
                'index' => 'name'
            ]
        );
        $this->addColumn(
            'type_id',
            [
                'header' => __('Type'),
                'sortable' => true,
                'index' => 'type_id'
            ]
        );
        $this->addColumn(
            'sku',
            [
                'header' => __('Sku'),
                'sortable' => false,
                'index' => 'sku'
            ]
        );
        return parent::_prepareColumns();
    }

    /**
     * get massaction
     * @return object
     */
    protected function _prepareMassaction()
    {
        $ruleId = $this->getRequest()->getParam('id');
        $this->setMassactionIdField('entity_id');
        $this->setChild('massaction', $this->getLayout()->createBlock($this->getMassactionBlockName()));
        $this->getMassactionBlock()->setFormFieldName('mageProEntityIds');
        $this->getMassactionBlock()->addItem(
            'delete',
            [
                'label' => __('Export To eBay'),
                'url' => $this->getUrl('multiebaystoremageconnect/*/syncinebay', ['rule_id'=>$ruleId])
            ]
        );
        return $this;
    }
}
