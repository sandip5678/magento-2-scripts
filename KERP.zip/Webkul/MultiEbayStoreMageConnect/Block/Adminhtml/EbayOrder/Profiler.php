<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Block\Adminhtml\EbayOrder;

class Profiler extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helperData;

    /**
     * @param \Magento\Backend\Block\Widget\Context $context
     * @param \Webkul\Ebaymagentoconnect\Helper\Data $helperData
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Widget\Context $context,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helperData,
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->helperData = $helperData;
    }

    /**
     * For get total imported order count.
     *
     * @return int
     */
    public function getImportedOrder()
    {
        $ruleId = $this->getRequest()->getParam('id');
        return $this->helperData->getTotalImportedCount('order', $ruleId);
    }
}
