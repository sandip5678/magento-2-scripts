<?php
/**
 * Webkul Software.
 * @package   Webkul_MultiEbayStoreMageConnect
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\MultiEbayStoreMageConnect\Model;

class PaymentMethod extends \Magento\OfflinePayments\Model\Cashondelivery
{
    const PAYMENT_METHOD_CASHONDELIVERY_CODE = 'multiebaypayment';

    /**
     * Payment method code
     *
     * @var string
     */
    protected $_code = 'multiebaypayment';

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_isOffline = true;

    /**
     * Get instructions text from config
     *
     * @return string
     */
    public function getInstructions()
    {
        return trim('');
    }

    /**
     * Check whether payment method can be used
     *
     * @param \Magento\Quote\Api\Data\CartInterface|null $quote
     * @return bool
     */
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        return true;
    }
}
