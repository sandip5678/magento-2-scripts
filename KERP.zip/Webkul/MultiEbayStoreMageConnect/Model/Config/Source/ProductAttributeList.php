<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Model\Config\Source;

class ProductAttributeList implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @var \Magento\Catalog\Api\ProductAttributeRepositoryInterface
     */
    private $productAttributeRepository;

    /**
     * @var \Magento\Framework\Api\SearchCriteriaBuilder
     */
    private $searchCriteria;

    /**
     * @param \Magento\Catalog\Api\ProductAttributeRepositoryInterface $productAttributeRepository,
     * @param \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteria
     */
    public function __construct(
        \Magento\Catalog\Api\ProductAttributeRepositoryInterface $productAttributeRepository,
        \Magento\Framework\Api\SearchCriteriaBuilder $searchCriteria
    ) {
        $this->productAttributeRepository = $productAttributeRepository;
        $this->searchCriteria = $searchCriteria;
    }
    /**
     * Return options array.
     *
     * @param int $store
     *
     * @return array
     */
    public function toOptionArray($store = null)
    {
        try {
            $optionArray = ["" => __('Select title attribute')];
            $searchCriteria = $this->searchCriteria->addFilter(
                'frontend_input',
                ['select', 'text', 'date', 'multiline', 'textarea', 'price', 'weight'],
                'in'
            )->addFilter('frontend_label', '', 'neq')->create();
            $attributeList = $this->productAttributeRepository->getList($searchCriteria)->getItems();

            foreach ($attributeList as $attribute) {
                $optionArray[$attribute->getAttributeCode()] = $attribute->getFrontendLabel();
            }
        } catch (\Exception $e) {
            $optionArray = ["" => __('Select title attribute')];
        }
        return $optionArray;
    }

    /**
     * Get options in "key-value" format.
     *
     * @return array
     */
    public function toArray()
    {
        return $this->toOptionArray();
    }
}
