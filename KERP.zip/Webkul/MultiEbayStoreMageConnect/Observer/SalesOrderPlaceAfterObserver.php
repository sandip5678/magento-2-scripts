<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\MultiEbayStoreMageConnect\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\MultiEbayStoreMageConnect\Api\ProductmapRepositoryInterface;

class SalesOrderPlaceAfterObserver implements ObserverInterface {
    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    private $productloader;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Api\ProductmapRepositoryInterface
     */
    private $productMapRepository;

    /**
     * @var \Magento\CatalogInventory\Model\Stock\StockItemRepository
     */
    private $stockItemRepository;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @param ProductmapRepositoryInterface $productMapRepository,
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
     * @param \Magento\Catalog\Model\ProductFactory $productloader
     */
    public function __construct(
        ProductmapRepositoryInterface $productMapRepository,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
        \Magento\Catalog\Model\ProductFactory $productloader
    ) {
        $this->productloader = $productloader;
        $this->logger = $helper->getLogger();
        $this->jsonHelper = $helper->getJsonHelper();
        $this->productMapRepository = $productMapRepository;
        $this->helper = $helper;
    }
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        try {
            $ebayOrderId = null;
            $order = $observer->getOrder();
            $lastOrderId = $order->getId();
            $orderIncrementedId = $order->getIncrementId();
            $orderItems = $order->getAllVisibleItems();
            foreach ($orderItems as $item) {
                $productIds[$item->getProductId()] = $item->getQtyOrdered();
            }
            $this->logger->info('Order quatity with product ids');
            $this->logger->info($this->jsonHelper->jsonEncode($productIds));

            foreach ($productIds as $productId => $itemOrderQty) {
                $product = $this->productloader->create()->load($productId);
                $ebayMappedModel = $this->productMapRepository->getRecordByMageProductId($productId)->getFirstItem();

                if ($ebayMappedModel->getEntityId()) {
                    $productQty = $product->getExtensionAttributes()->getStockItem()->getQty();
                    $ebayItemId = $ebayMappedModel->getEbayProId();
                    $ruleId = $ebayMappedModel->getRuleId();
                    $eBayConfig = $this->helper->getEbayAPI($ruleId);
                    if ($eBayConfig) {
                        $this->logger->info(' updated product quantity in ebay');
                        $params = ['Version' => 849, 'ItemID' => $ebayItemId, 'DetailLevel' => 'ReturnAll'];
                        $resultsProduct = $eBayConfig->GetItem($params);
                        $ebayTotalQty = $resultsProduct->Item->Quantity;
                        $ebaySoldQty = $resultsProduct->Item->SellingStatus->QuantitySold;
                        $actualQty = $ebayTotalQty - ($ebaySoldQty + $itemOrderQty);

                        $ebayParams = [
                            'Version' => 891,
                            'Item' => [
                                "ItemID" => $ebayItemId,
                                'Quantity' => $actualQty,
                            ],
                            'WarningLevel' => 'High',
                        ];

                        if ($ebayMappedModel->getProductType() === "configurable") {
                            $variations = $this->helper->getProductVariationForEbay($product, [], $ruleId);
                            $ebayParams['Item']['Variations'] = $variations;
                            unset($ebayParams['Item']['StartPrice']);
                            unset($ebayParams['Item']['Quantity']);
                            $response = $eBayConfig->ReviseFixedPriceItem($ebayParams);
                        } else {
                            $response = $eBayConfig->ReviseItem($ebayParams);
                        }


                        $this->logger->info('eBay response regarding quantity updation');
                        $this->logger->info($this->jsonHelper->jsonEncode($response));
                    } else {
                        $this->logger->info('ebay details not correct ' . $ebayMappedModel->getRuleId());
                    }
                } else {
                    $this->logger->info('this product id ' . $productId . ' is not an ebay product');
                }
            }
        } catch (\Exception $e) {
            $this->logger->addError('Observer SalesOrderPlaceAfterObserver : ' . $e->getMessage());
            $this->logger->addError('Observer SalesOrderPlaceAfterObserver : ' . $e->getFile());
        }
    }
}
