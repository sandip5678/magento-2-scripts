<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Observer;

use Magento\Framework\Event\ObserverInterface;

class ChangeTaxTotal implements ObserverInterface
{
    /**
     * @var \Magento\Backend\Model\Session
     */
    private $backendSession;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @param \Magento\Backend\Model\Session $backendSession,
     * @param \Webkul\MultiEbayStoreMageConnect\Logger\Logger $logger,
     */

    public function __construct(
        \Magento\Backend\Model\Session $backendSession,
        \Webkul\MultiEbayStoreMageConnect\Logger\Logger $logger
    ) {
        $this->backendSession = $backendSession;
        $this->ebayLogger = $logger;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            /** @var Magento\Quote\Model\Quote\Address\Total */
            $additionalTaxAmt = $this->backendSession->getEbayTotalTaxAmount();
            $total = $observer->getData('total');

            //make sure tax value exist
            if ($additionalTaxAmt) {
                $total->addTotalAmount('tax', $additionalTaxAmt);
                $total->setGrandTotal($total->getGrandTotal() + $additionalTaxAmt);
                $total->setBaseGrandTotal($total->getBaseGrandTotal() + $additionalTaxAmt);
            }
            return $this;
        } catch (\Exception $e) {
            $this->ebayLogger->addError('ChangeTaxTotal : '.$e->getMessage());
            return $this;
        }
    }
}
