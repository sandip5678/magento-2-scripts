<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Observer;

use Ebay;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\Exception\LocalizedException;

class AdminSystemConfigChangedObserver implements ObserverInterface
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    private $request;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     *
     * @param RequestInterface $requestInterface
     * @param \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
     */
    public function __construct(
        RequestInterface $requestInterface,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper
    ) {
        $this->request = $requestInterface;
        $this->helper = $helper;
        $this->logger = $helper->getLogger();
    }

    /**
     * admin_system_config_changed_section_mppushnotification event handler.
     *
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        try {
            $data =  $this->request->getParams();
            $fields = $data['groups']['ebay_event']['fields'];
            $client = $this->helper->getEbayAPI();
            if (isset($fields['notification_status']['value'])
                && $eventList = $fields['notification_status']['value']) {
                $this->helper->enableEventNotification($client, 0, $eventList);
            } else {
                $this->helper->disableEventNotification($client, 0);
            }
        } catch (\Exception $e) {
            $this->logger->addError('AdminSystemConfigChangedObserver : '.$e->getMessage());
        }
    }
}
