<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\MultiEbayStoreMageConnect\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Session\SessionManager;

class RemoveTaxBeforeCollectTotal implements ObserverInterface
{
    public function __construct(
        SessionManager $session
    ) {
        $this->session = $session;
    }

    /**
     * @param \Magento\Framework\Event\Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $items = $observer->getEvent()->getQuote()->getAllVisibleItems();
        $flag = (int)$this->session->getIsEbayOrder();
        if ($flag) {
            foreach($items as $item) {
                $item->getProduct()->setTaxClassId(0);
            }
        }
    }
}
