<?php
/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\MultiEbayStoreMageConnect\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\MultiEbayStoreMageConnect\Api\ProductmapRepositoryInterface;

class CatalogProductSaveAfter implements ObserverInterface {
    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Logger\Logger
     */
    private $logger;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Api\ProductmapRepositoryInterface
     */
    private $productMapRepository;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    private $managerInterface;

    /**
     * @var \Magento\CatalogInventory\Api\StockRegistryInterface
     */
    private $stockItemRepository;

    /**
     * @var \Webkul\MultiEbayStoreMageConnect\Helper\Data
     */
    private $helper;

    /**
     * @var \Magento\Backend\Model\Session
     */
    private $backendSession;

    /**
     * @param ProductmapRepositoryInterface $productMapRepository,
     * @param Magento\Framework\Message\ManagerInterface $managerInterface,
     * @param Magento\CatalogInventory\Api\StockRegistryInterface $stockItemRepository,
     * @param Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
     * @param Magento\Backend\Model\Session $backendSession
     */
    public function __construct(
        ProductmapRepositoryInterface $productMapRepository,
        \Magento\Framework\Message\ManagerInterface $managerInterface,
        \Magento\CatalogInventory\Api\StockRegistryInterface $stockItemRepository,
        \Webkul\MultiEbayStoreMageConnect\Helper\Data $helper,
        \Magento\Backend\Model\Session $backendSession,
        \Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable $configPro,
        \Magento\Catalog\Model\ProductFactory $productFactory
    ) {
        $this->logger = $helper->getLogger();
        $this->jsonHelper = $helper->getJsonHelper();
        $this->messageManager = $managerInterface;
        $this->productMapRepository = $productMapRepository;
        $this->stockItemRepository = $stockItemRepository;
        $this->helper = $helper;
        $this->backendSession = $backendSession;
        $this->configPro = $configPro;
        $this->productFactory = $productFactory;
    }
    /**
     *
     * @param \Magento\Framework\Event\Observer $observer
     * @return $this
     */
    public function execute(\Magento\Framework\Event\Observer $observer) {
        try {
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/save-after.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
            $logger->info("call");
            if (!$this->backendSession->getEbaySession()) {
                $product = $observer->getProduct();
                if ($product->getVisibility() == 1) {
                    $mainProductId = $this->configPro->getParentIdsByChild($product->getId());
                    if (isset($mainProductId[0])) {
                        $ebayMappedModel = $this->productMapRepository->getRecordByMageProductId($mainProductId[0])
                            ->setPageSize(1)->getFirstItem();
                        if ($ebayMappedModel->getEntityId()) {
                            $product = $this->productFactory->create()->load($mainProductId[0]);
                        }
                    }
                } else {
                    $ebayMappedModel = $this->productMapRepository->getRecordByMageProductId($product->getId())
                        ->setPageSize(1)->getFirstItem();
                }
                if ($ebayMappedModel->getEntityId()) {
                    $conditionId = 1000; /** for new product */
                    $eBayDefaultSetting = $this->helper->getEbayDefaultSettings($ebayMappedModel->getRuleId());
                    if (isset($eBayDefaultSetting['reviseItem']) && $eBayDefaultSetting['reviseItem']) {
                        $client = $this->helper->getEbayAPI($ebayMappedModel->getRuleId());
                        $productStock = $this->stockItemRepository->getStockItem(
                            $product->getId(),
                            $product->getStore()->getWebsiteId()
                        );
                        $pictureDetails = $this->helper->getPictureUrl($product);
                        if ($ebayMappedModel->getConditionAttribute()) {
                            $conditionId = $product->getAttributeText($ebayMappedModel->getConditionAttribute());
                            if ($conditionId != '') {
                                $conditionId = explode(' for ', $conditionId);
                                $conditionId = (int) $conditionId[0];
                            } else {
                                $conditionId = 1000; /** for new product */
                            }
                        }
                        $productDescription = $this->helper->getProductDescription(
                            $product,
                            $eBayDefaultSetting,
                            $this->helper->config['template_id']
                        );
                        $productCost = $this->helper->getPriceAfterAppliedRule($product->getPrice(), 'export');
                        $qty = $product->getEbayMaxQty();
                        $logger->info($qty);
                        if ($productStock->getQty() < $qty) {
                            $qty = $productStock->getQty();
                        }
                        $logger->info($qty);
                        $ebayParams = [
                            'Version' => 891,
                            'Item' => [
                                "ItemID" => $ebayMappedModel->getEbayProId(),
                                "Title" => $product->getName(),
                                'StartPrice' => $productCost['price'],
                                'Description' => $productDescription,
                                'Currency' => $eBayDefaultSetting['Currency'],
                                'Quantity' => $qty,
                                'PictureDetails' => $pictureDetails,
                                'ShippingPackageDetails' => [
                                    'MeasurementUnit' => 'English',
                                    'WeightMajor' => $product->getWeight(),
                                    'WeightMinor' => $product->getWeight() - 1,
                                ],
                            ],
                            'WarningLevel' => 'High',
                        ];
                        $logger->info($ebayParams);
                        if ($conditionId) {
                            $ebayParams['Item']['ConditionID'] = $conditionId;
                        }
                        //Check subtitle enable and set it to item
                        if ($eBayDefaultSetting['UseSubTitle']) {
                            $attrValue = $product->getResource()->getAttribute($eBayDefaultSetting['SubTitleAttr']);
                            if ($attrValue) {
                                $attrValue = $attrValue->getFrontend()->getValue($product);
                                $attrValue = $attrValue == 'No' ? 'N/A' : $attrValue;
                                $ebayParams['Item']['SubTitle'] = substr($attrValue, 0, 55);
                            }
                        }

                        if ($ebayMappedModel->getProductType() === "configurable") {
                            $variations = $this->helper->getProductVariationForEbay($product, [], $ebayMappedModel->getRuleId());
                            $ebayParams['Item']['Variations'] = $variations;
                            unset($ebayParams['Item']['StartPrice']);
                            unset($ebayParams['Item']['Quantity']);
                        }
                        $response = $client->ReviseFixedPriceItem($ebayParams);
                        if (isset($response->Ack) && ((string) $response->Ack == 'Success'
                            || (string) $response->Ack == 'Warning')) {
                            $infoMsg = 'Magento product id ' . $product->getId() . 'revised at eBay Item Id '
                            . $ebayMappedModel->getEbayProId();
                            $this->logger->info($infoMsg);
                        } else {
                            $this->manageError($response, $product->getSku());
                        }
                        $this->logger->info('Observer CatalogProductSaveAfter : ebay update reponse');
                        $this->logger->info($this->jsonHelper->jsonEncode($response));
                    }
                }
            }
        } catch (\Exception $e) {
            $this->logger->info('Observer CatalogProductSaveAfter' . $e->getMessage());
        }
    }

    /**
     * manageError
     * @param Object $response
     * @param string $proSku
     * @return void
     */
    private function manageError($response, $proSku) {
        try {
            $this->logger->addError($this->jsonHelper->jsonEncode($response));
            $infoMsg = 'issue return for eBay end so product did not update on eBay end.';
            if (isset($response->Errors) && is_object($response->Errors)) {
                $infoMsg = $response->Errors->ShortMessage . ' (SKU - ' . $proSku . ')';
                $this->messageManager->addNotice($infoMsg);
            } else {
                if (isset($response->Errors)) {
                    foreach ($response->Errors as $error) {
                        $infoMsg = $error->ShortMessage . ' (SKU - ' . $proSku . ')';
                        $this->messageManager->addNotice($infoMsg);
                    }
                } else {
                    $infoMsg = isset($response->detail) ? $response->faultstring . __(' eBay store error code :')
                    . $response->detail->FaultDetail->ErrorCode : $response->faultstring;
                    $this->messageManager->addNotice($infoMsg);
                }
            }
        } catch (\Exception $e) {
            $this->logger->addError('manageError : ' . $e->getMessage());
            $this->messageManager->addNotice($e->getMessage());
        }
    }
}
