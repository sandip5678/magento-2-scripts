/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
/*jshint jquery:true*/
define([
    'jquery',
    'mage/loader',
    'mage/template',
    'mage/calendar',
    'text!Webkul_MultiEbayStoreMageConnect/templates/grid/cells/ordermap/date-for-import-ebay-order.html'
], function ($, loader, template, calendar, templateHtml) {
    'use strict';
    var id,popup;
    var page = 1;var requests = [];var totalImportedOrder = 0;var notifications = '';
    $.widget('mage.orderImportScript', {
        _create: function () {
            var self = this;
            $(this.options.importOrderSelector).click(function(e){
                id = $('#entity_id').val();
                //$('#sync_from_ebay .action-toggle').trigger('click');
                e.preventDefault();
                var modalHtml = template(templateHtml, {formaction: "#"});
                $('<div />').html(modalHtml)
                    .modal({
                        title: $.mage.__('Enter Date Range For Import Order From eBay'),
                        autoOpen: true,
                        opened: function(){
                            var dateRange = $("#date_range").dateRange({
                                 buttonText:$.mage.__('Select Date'),
                                // dateFormat: "dd-mm-Y",
                                 from:{
                                    id:"date_from",
                                 },
                                 to:{
                                    id:"date_to"
                                 }
                           });
                        },
                        closed: function () {
                            $('.modals-wrapper').remove();
                        },
                        buttons: [{
                         text: 'Import Order From eBay',
                            attr: {
                                'data-action': 'button'
                            },
                            'class': 'action-primary',
                            click: function() {
                                var dateFrom = $('#date_from').val();
                                var dateTo = $('#date_to').val();
                                if (dateFrom && dateTo) {
                                    $('#date_from, #date_to').removeAttr('style');
                                    importOrders(dateFrom, dateTo);
                                    this.closeModal();
                                } else {
                                    $('#date_from, #date_to').css('border', '1px solid rgb(255, 0, 0)');
                                    return false;
                                }
                            }
                        }]
                    });
            });

            var importOrders = function (dateFrom, dateTo) {
               $.ajax({
                   url     :   self.options.importAjaxUrl,
                   type    :   "POST",
                   dataType:   "json",
                   showLoader: true,
                   data: {
                       form_key: window.FORM_KEY,
                       'page' : page,
                       'from_date': dateFrom,
                       'from_to': dateTo,
                       'id' : id
                   },
                   success : function (ebayOrder) {
                       if (ebayOrder.error_msg != '') {
                           $('<div />').html(ebayOrder.error_msg)
                                       .modal({
                                           title: $.mage.__('Attention'),
                                           autoOpen: true,
                                           buttons: [{
                                            text: 'OK',
                                               attr: {'data-action': 'cancel'},
                                               'class': 'action-primary',
                                               click: function () {
                                                       this.closeModal();
                                                   }
                                           }]
                                       });
                       } else if (ebayOrder.total_imported == false) {
                           page = page+1;
                           totalImportedOrder = totalImportedOrder + ebayOrder.data;
                           notifications = notifications+ebayOrder.notification;
                           importOrders(dateFrom, dateTo);
                       } else {
                           if (ebayOrder.total_imported == true) {
                               totalImportedOrder = totalImportedOrder + ebayOrder.data
                               notifications = notifications+ebayOrder.notification;
                               var msg =$.mage.__('Total ')+totalImportedOrder +$.mage.__(' orders imported in your store from eBay.');
                               if (totalImportedOrder == 0) {
                                   msg = $.mage.__('All the orders are already imported. There is no new order to import.');
                               }
                               msg += totalImportedOrder ? $.mage.__(' Now run order profiler for create these order in your store') : '';
                               var notification = '';
                               if ($('<div />').html(notifications).text() != '') {
                                   var actionMsg = $.mage.__('For import following orders please follow : <br />');
                                   var actionForCreatePro = "<b>eBay Account >> Map Product >> Run Profiler</b>";
                                   notification = '<div class="message notification">'+actionMsg
                                                           +actionForCreatePro+'</div><div style="color:red;">'+ebayOrder.notification+notifications+'</div>';
                               }
                               //var notification = '<div style="color:red;">'+ebayOrder.notification+'</div>';
                               $('<div />').html(msg+notification)
                                   .modal({
                                       title: $.mage.__('Attention'),
                                       autoOpen: true,
                                       buttons: [{
                                        text: 'OK',
                                           attr: {'data-action': 'cancel'},
                                           'class': 'action-primary',
                                           click: function () {
                                                   this.closeModal();
                                               }
                                       }]
                                   });
                           }
                           page = 1;
                           totalImportedOrder = 0;
                           notifications = '';
                       }
                   }
               });
           }

            $(self.options.profilerSelector).click(function (e) {
                var width = '1100';
                var height = '400';
                var scroller = 1;
                var screenX = typeof window.screenX != 'undefined' ? window.screenX : window.screenLeft;
                var screenY = typeof window.screenY != 'undefined' ? window.screenY : window.screenTop;
                var outerWidth = typeof window.outerWidth != 'undefined' ? window.outerWidth : document.body.clientWidth;
                var outerHeight = typeof window.outerHeight != 'undefined' ? window.outerHeight : (document.body.clientHeight - 22);
                var left = parseInt(screenX + ((outerWidth - width) / 2), 10);
                var top = parseInt(screenY + ((outerHeight - height) / 2.5), 10);

                var settings = (
                    'width=' + width +
                    ',height=' + height +
                    ',left=' + left +
                    ',top=' + top +
                    ',scrollbars=' + scroller
                    );
                popup = window.open(self.options.profilerAjaxUrl,'',settings);
                popup.onunload = self.afterChildClose;
            });
        },
        afterChildClose:function () {
            if (popup.location != "about:blank") {
                $('button[title="Reset Filter"]').trigger('click');
            }
        }
    });
    return $.mage.orderImportScript;
});
