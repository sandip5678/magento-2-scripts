/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) 2010-2017 Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
/*jshint jquery:true*/
define([
    "jquery",
    "mage/translate",
], function ($, $t) {
    "use strict";
    var popup;
    $.widget('ebayConnect.authorizeEbayUser', {
        _create: function () {
            var self = this;
            var globalSite;var notificationStatus;

            // re auth click event
            $('#save').on('click', function (e) {
                $('#ebay_map_category_massaction-select').prop('disabled', true);
                $('#ebay_map_product_massaction-select').prop('disabled', true);
                $('#ebay_map_order_massaction-select').prop('disabled', true);
                $('#mage_map_product_massaction-select').prop('disabled', true);
                $('#edit_form').submit();
            });
            $('body').on('click','#save-btn-reauth', function () {
                $('.wk-mp-design-ebay').removeClass('block-hide');
                $('.verfied-ebay-user-container').addClass('block-hide');
            });
            $('body').on('click', '.ebay-authorize', function () {
                globalSite = $('#global_site').val();
                var postalCode = $('#shop_postal_code').val();
                var storeName = $('#store_name').val();
                var attributeSetId = $('#attribute_set_id').val();
                if (globalSite && postalCode && storeName) {
                    $.ajax({
                        url : self.options.sessionUrl,
                        data: {
                            form_key: window.FORM_KEY,
                        },
                        type : 'post',
                        showLoader : true,
                        datatype : 'json',
                        success : function (result) {
                            if (result.error == 0) {
                                var rupatams = encodeURIComponent("globalSite="+globalSite+"&storeName="+storeName+"&postalCode="+postalCode+"&sessid="+result.sessionId+"&attributeset_id="+attributeSetId);
                                var AuthUrl = self.options.auth_url+"&runame="+result.ruName+"&SessID="+encodeURIComponent(result.sessionId)+"&ruparams="+rupatams;
                                var width = '700';
                                var height = '400';
                                var scroller = 1;
                                var screenX = typeof window.screenX != 'undefined' ? window.screenX : window.screenLeft;
                                var screenY = typeof window.screenY != 'undefined' ? window.screenY : window.screenTop;
                                var outerWidth = typeof window.outerWidth != 'undefined' ? window.outerWidth : document.body.clientWidth;
                                var outerHeight = typeof window.outerHeight != 'undefined' ? window.outerHeight : (document.body.clientHeight - 22);
                                var left = parseInt(screenX + ((outerWidth - width) / 2), 10);
                                var top = parseInt(screenY + ((outerHeight - height) / 2.5), 10);

                                var settings = (
                                    'width=' + width +
                                    ',height=' + height +
                                    ',left=' + left +
                                    ',top=' + top +
                                    ',scrollbars=' + scroller
                                    );

                                popup = window.open(AuthUrl, "eBay User Authorization", settings);
                                try {
                                    var timer = setInterval(function () {
                                        if (popup && popup.closed) {
                                            clearInterval(timer);
                                            $('#save').removeAttr('disabled');
                                            $('#save').click();
                                        }
                                    }, 1000);
                                } catch(e) {
                                    console.log('Please enable popup');
                                }

                            } else {
                                alert('Something went wrong');
                            }
                        }
                    });
                } else {
                    alert('Please fill all required Fields.');
                }
            });
        }

    });
    return $.ebayConnect.authorizeEbayUser;
});
