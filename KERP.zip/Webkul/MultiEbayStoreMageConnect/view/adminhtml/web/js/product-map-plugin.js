/**
 * @category   Webkul
 * @package    Webkul_MultiEbayStoreMageConnect
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
/*jshint jquery:true*/
define([
    'jquery',
    'mage/translate',
    'Magento_Ui/js/modal/alert',
    'mage/loader',
    'mage/template',
    'mage/calendar',
    'text!Webkul_MultiEbayStoreMageConnect/templates/grid/cells/productsmap/date-for-export-ebay.html'
], function ($,$t,alert, loader, template, calendar, templateEbayExport) {
    'use strict';
    var id,popup;var flag = 1;
    var requests = [], page = 1; var totalImportedProduct=0;
    var index = 0;var mappedCates = [];
    $.widget('mage.productImportScript', {
        _create: function () {
            var self = this;
            var totalImportedProduct = 0;var page = 1;
            mappedCates = self.options.cates.split(",");
            var currentCategory = mappedCates.pop();
            $(this.options.importProductSelector).click(function (e) {
                id = $('#entity_id').val();
                var subcat=$(this);
                e.preventDefault();
                var error_msg = '';
                var modalHtml = template(
                    templateEbayExport,
                    {formaction: self.options.importAjaxUrl}
                );
                var modalPopup = $('<div />').html(modalHtml)
                .modal({
                    title: $.mage.__('Enter Date Range For Import Product From eBay'),
                    autoOpen: true,
                    opened: function(){
                        var dateRange = $("#date_range").dateRange({
                             buttonText:$.mage.__('Select Date'),
                             from:{
                                id:"date_from",
                             },
                             to:{
                                id:"date_to"
                             }
                       });
                    },
                    closed: function () {
                        $('.modals-wrapper').remove();
                    },
                    buttons: [{
                     text: 'Import Product From eBay',
                        attr: {
                            'data-action': 'button'
                        },
                        'class': 'action-primary',
                        click: function() {
                            var dateFrom = $('#date_from').val();
                            var dateTo = $('#date_to').val();
                            var onlyActive = $('#active_pro_only').prop('checked');
                            if (dateFrom && dateTo) {
                                $('#date_from, #date_to').removeAttr('style');
                                importProducts(dateFrom, dateTo, page, onlyActive);
                                this.closeModal();
                            } else {
                                $('#date_from, #date_to').css('border', '1px solid rgb(255, 0, 0)');
                                return false;
                            }
                        }
                    }]
                });
                var importProducts = function (dateFrom, dateTo, page, onlyActive) {
                    $.ajax({
                        url     :   self.options.importAjaxUrl,
                        type    :   "POST",
                        dataType:   "json",
                        showLoader: true,
                        data: {
                            form_key: window.FORM_KEY,
                            'id' : id,
                            'page' : page,
                            'from_date': dateFrom,
                            'from_to': dateTo,
                            'only_active': onlyActive,
                            'category' : currentCategory
                        },
                        success : function(ebayPro){
                            if(ebayPro.error_msg != false) {
                                error_msg = ebayPro.error_msg;
                                $('<div />').html(ebayPro.error_msg)
                                .modal({
                                    title: $.mage.__('Attention'),
                                    autoOpen: true,
                                    opened:function() {
                                        $('.ebaymagentoconnect-ebayorder-index .action-close').remove();
                                    },
                                    buttons: [{
                                     text: 'OK',
                                        attr: {
                                            'data-action': 'cancel'
                                        },
                                        'class': 'action-primary',
                                        click: function() {
                                                this.closeModal();
                                            }
                                    }]
                                });
                            } else if (ebayPro.total_imported == false) {
                                page = page+1;
                                totalImportedProduct = totalImportedProduct + ebayPro.data;
                                importProducts(dateFrom, dateTo, page, onlyActive);
                            } else if (ebayPro.total_imported == true && mappedCates.length != 0) {
                                currentCategory = mappedCates.pop();
                                page = 1;
                                totalImportedProduct = totalImportedProduct + ebayPro.data;
                                importProducts(dateFrom, dateTo, page, onlyActive);
                            } else {
                                $(".admin__menu-overlay, .loading-mask").css('display', 'none');
                                totalImportedProduct = totalImportedProduct + ebayPro.data;
                                var alertMsg = totalImportedProduct ? totalImportedProduct + $.mage.__(' Products imported successfully.')
                                                    + $.mage.__('run products profiler for create these products in your store.')
                                                    : $.mage.__('All products are imported from eBay or there are no products to import from eBay');
                                $('<div />').html(jQuery('<div/>').addClass('count').text(alertMsg))
                                .modal({
                                    title: $.mage.__('Success'),
                                    autoOpen: true,
                                    buttons: [{
                                     text: 'OK',
                                        attr: {
                                            'data-action': 'cancel'
                                        },
                                        'class': 'action-primary',
                                        click: function() {
                                                this.closeModal();
                                            }
                                    }]
                                });
                                totalImportedProduct = 0;
                                page = 1;
                            }
                        }
                    });
                };
            });
            $(self.options.profilerSelector).click(function (e) {
                var width = '1100';
                var height = '400';
                var scroller = 1;
                var screenX = typeof window.screenX != 'undefined' ? window.screenX : window.screenLeft;
                var screenY = typeof window.screenY != 'undefined' ? window.screenY : window.screenTop;
                var outerWidth = typeof window.outerWidth != 'undefined' ? window.outerWidth : document.body.clientWidth;
                var outerHeight = typeof window.outerHeight != 'undefined' ? window.outerHeight : (document.body.clientHeight - 22);
                var left = parseInt(screenX + ((outerWidth - width) / 2), 10);
                var top = parseInt(screenY + ((outerHeight - height) / 2.5), 10);

                var settings = (
                    'width=' + width +
                    ',height=' + height +
                    ',left=' + left +
                    ',top=' + top +
                    ',scrollbars=' + scroller
                    );
               popup = window.open(self.options.profilerAjaxUrl,'',settings);
               popup.onunload = self.afterChildClose;
            });
        },
        afterChildClose:function () {
            if (popup.location != "about:blank") {
                window.location.search += "&active_tab=mapproduct";
                // $('button[title="Reset Filter"]').trigger('click');
            }
        }
    });
    return $.mage.productImportScript;
});
